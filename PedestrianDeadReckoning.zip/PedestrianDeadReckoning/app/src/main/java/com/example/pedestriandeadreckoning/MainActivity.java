package com.example.pedestriandeadreckoning;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.ContentValues;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Arrays;
import java.util.List;

import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.view.LineChartView;
import android.graphics.Color;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity implements SensorEventListener{

    public SensorManager sensorManager;
    public TextView textViewConteoPasos;
    public TextView textViewConteoDistancia;
    public Sensor mAccelerometer;
    public EditText editTextNumberDecimal;
    public EditText editTextNumberDecimal2;
    public EditText editTextNumberDecimal3;
    public EditText editTextNumberDecimal4;
    public EditText editTextNumberDecimalAltura;
    public EditText editTextTextMultiLine;
    public Switch switch1;
    public LineChartView lineChartView;//Fijo para graficar

    public double [] AccEjeX = new double[50000];
    public double [] AccEjeY = new double[50000];
    public double [] AccEjeZ = new double[50000];
    public double [] AccXYZ = new double[50000];
    public double[] Azimuth = new double[50000];
    public double [] GyrEjeX = new double[50000];
    public double [] GyrEjeY = new double[50000];
    public double [] GyrEjeZ = new double[50000];
    public double [] GyrXYZ = new double[50000];
    public double [] TIEMPO = new double[50000];
    public double [][] MatDyD = new double[2][5000];
    public double [][] MatXY = new double[2][5000];
    public double [][] MatXY_rotada = new double[2][5000];

    public double AnguloActual = 0;
    public int contIndice = 0;
    public int indiceInicio = 0;
    public int indiceInicioT = 0;
    public int contadorDyD = 0;
    public boolean primer_valor_dif_cero = false;
    public double altura = 0;
    int codigo = 1;
    public boolean InicioAnalisis = false; //Guardar ventana de datos
    public boolean InicioAnalisis2 = false; //Iniciar proceso de filtro
    public boolean InicioAnalisis3 = false; //Inicia detección de cruces por cero
    public boolean InicioAnalisis4 = false; //Inicia detección de picos
    public boolean InicioAnalisis5 = false; //Inicia detección de valles
    public boolean InicioAnalisis6 = false; //Inicia unión de cruces, picos y valles
    public boolean InicioAnalisis8 = false; //Inicia emparejamiento Vcpv definitivo
    public boolean InicioAnalisis9 = false; //Inicia conteo de pasos (Swing o Texting)
    public boolean Detener = false; //Detiene todo el proceso

    public int ventanaTiempo = 50; //Dado que el sistema muestrea a 50Hz, 50 equivale a 1 segundo
    public int lateral_ventana = 30;
    public double [] ventanaAccXYZ = new double[ventanaTiempo];
    public double [] ventanaAccX = new double[ventanaTiempo];
    public double [] ventanaAccY = new double[ventanaTiempo];
    public double [] ventanaAccZ = new double[ventanaTiempo];
    public double[] ventanaAzimuth = new double[ventanaTiempo];
    public double [] ventanaGyrX = new double[ventanaTiempo];
    public double [] ventanaGyrY = new double[ventanaTiempo];
    public double [] ventanaGyrZ = new double[ventanaTiempo];
    public double [] ventanaGyrXYZ = new double[ventanaTiempo];
    public double [] AccXYZfiltrada = new double[ventanaTiempo];
    public double [] AccXYZfiltrada_90 = new double[ventanaTiempo+lateral_ventana+lateral_ventana];
    public double [] Tiempo_ventanaAccXYZ = new double[ventanaTiempo];
    public double [] CrucesPorCeroAccXYZ = new double[ventanaTiempo];
    public double [] PicosAccXYZ = new double[ventanaTiempo];
    public double [] VallesAccXYZ = new double[ventanaTiempo];
    public double [] UnionCPVAccXYZ = new double[ventanaTiempo];
    public double [] CrucesPorCeroAccXYZ_sinFiltrar = new double[ventanaTiempo];
    public double [] PicosAccXYZ_sinFiltrar = new double[ventanaTiempo];
    public double [] VallesAccXYZ_sinFiltrar = new double[ventanaTiempo];
    public double [] UnionCPVAccXYZ_sinFiltrar = new double[ventanaTiempo];
    public double [] Vcpv_PyV_emparejado = new double [ventanaTiempo];
    public double [][] Matriz_general_conteo_pasos = new double [8][8];
    public double [][] Matriz_distancia_tiempos = new double [3][8];
    public double [][] Matriz_distancia_direccion = new double [2][8];
    public double [][] Matriz_DyD_unidas = new double [2][8];
    public double [][] Matriz_x_y = new double [2][8];
    public double theta_rotacion = 0;//55; //Grados de rotación constantes para el plano de mi casa
    public int fc = 6;//Hz ->Frecuencia de corte filtro pasa bajas
    public double umbralPicos = 0.7; //Umbral de análisis para detección de picos //2.5_swing
    public double umbralValles = -0.4; //Umbral de análisis para detección de valles //-2_swing
    public double umbralPicos_sinFiltrar = 1.2;
    public double umbralValles_sinFiltrar = -0.6;
    public int id_actividad = 1; //Por defecto en balanceo
    public int id_act_anterior = 2;

    public String imprimirX = "";
    public String imprimirY = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        //Instanciar variables
        textViewConteoPasos = findViewById(R.id.textViewConteoPasos);
        textViewConteoDistancia = findViewById(R.id.textViewConteoDistancia);
        editTextTextMultiLine = findViewById(R.id.editTextTextMultiLine);
        switch1 = findViewById(R.id.switch1);
        lineChartView = findViewById(R.id.chart);//Fijo para graficar
        /*editTextNumberDecimal = findViewById(R.id.editTextNumberDecimal);
        editTextNumberDecimal2 = findViewById(R.id.editTextNumberDecimal2);
        editTextNumberDecimal3 = findViewById(R.id.editTextNumberDecimal3);
        editTextNumberDecimal4 = findViewById(R.id.editTextNumberDecimal4);
        editTextNumberDecimalAltura = findViewById(R.id.editTextNumberDecimalAltura);

        //Establece la orientación de la pantalla en modo retrato-vertical
        this.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        //this.editTextNumberDecimal.setText(umbralPicos+"");
        this.editTextNumberDecimal2.setText(umbralValles*(-1)+"");
        this.editTextNumberDecimal3.setText(umbralPicos_sinFiltrar+"");
        this.editTextNumberDecimal4.setText(umbralValles_sinFiltrar*(-1)+"");
        this.editTextNumberDecimalAltura.setText(altura+"");

        AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,"administracion",null,1);
        SQLiteDatabase BaseDeDatos = admin.getWritableDatabase();
        Cursor fila = BaseDeDatos.rawQuery("select umbralpsf, umbralvsf, umbralpcf, umbralvcf, altura from umbralesyaltura where codigo = "+codigo,null);
        if(fila.moveToFirst()){
            //Método para imprimir en los editText
            this.editTextNumberDecimal.setText(fila.getString(2));
            this.editTextNumberDecimal2.setText(fila.getString(3));
            this.editTextNumberDecimal3.setText(fila.getString(0));
            this.editTextNumberDecimal4.setText(fila.getString(1));
            this.editTextNumberDecimalAltura.setText(fila.getString(4));
            altura = Double.parseDouble(fila.getString(4));
        }else{
            Toast.makeText(getApplicationContext(),"Por favor, ingrese su altura",Toast.LENGTH_LONG).show();
            BaseDeDatos.close();
        }
        if(altura>0){
            umbralPicos = Double.parseDouble(fila.getString(2));
            umbralValles = Double.parseDouble(fila.getString(3))*(-1);
            umbralPicos_sinFiltrar = Double.parseDouble(fila.getString(0));
            umbralValles_sinFiltrar = Double.parseDouble(fila.getString(1))*(-1);
            Toast.makeText(getApplicationContext(),"Todo listo para iniciar recorrido",Toast.LENGTH_SHORT).show();
            BaseDeDatos.close();
        }
        */
        Toast.makeText(getApplicationContext(),"Todo listo para iniciar recorrido",Toast.LENGTH_SHORT).show();
    }

    //Lo que se hace cada vez que se reanuda, pausa o para la aplicación
    protected void onResume(){
        super.onResume();
        int READRATE = 20000; //Tiempo en microsegundos
        Sensor accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if(accelerometer != null){
            sensorManager.registerListener(this,accelerometer,READRATE);
        }
        Sensor orientation = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);
        if(orientation != null){
            sensorManager.registerListener(this,orientation,READRATE);
        }
        Sensor gyroscope = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        if(gyroscope != null){
            sensorManager.registerListener(this,gyroscope,READRATE);
        }
    }
    protected void onPause(){
        super.onPause();
    }
    protected void onStop(){
        super.onStop();
    }


    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {

        if (sensorEvent.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            AccEjeX[contIndice] = sensorEvent.values[0];
            AccEjeY[contIndice] = sensorEvent.values[1];
            AccEjeZ[contIndice] = sensorEvent.values[2];
            AccXYZ[contIndice] = Math.sqrt(Math.pow(AccEjeX[contIndice], 2) + Math.pow(AccEjeY[contIndice], 2) + Math.pow(AccEjeZ[contIndice], 2)) - 9.81;
            TIEMPO[contIndice] = contIndice * 0.02;
            TIEMPO[contIndice] = Math.round(TIEMPO[contIndice]*100);
            TIEMPO[contIndice] = TIEMPO[contIndice]/100;
        }else if (sensorEvent.sensor.getType() == Sensor.TYPE_ORIENTATION) {
            Azimuth[contIndice] = sensorEvent.values[0];
        }else if (sensorEvent.sensor.getType() == Sensor.TYPE_GYROSCOPE){
            GyrEjeX[contIndice] = sensorEvent.values[0];
            GyrEjeY[contIndice] = sensorEvent.values[1];
            GyrEjeZ[contIndice] = sensorEvent.values[2];
            GyrEjeZ[contIndice] = (GyrEjeZ[contIndice]*180/Math.PI)*(-1)*0.02;
            if(contIndice!=0){
                GyrEjeZ[contIndice] = GyrEjeZ[contIndice]+GyrEjeZ[contIndice-1]; //Acumula los ángulos
            }
            GyrXYZ[contIndice] = Math.sqrt(Math.pow(GyrEjeX[contIndice], 2) + Math.pow(GyrEjeY[contIndice], 2) + Math.pow(GyrEjeZ[contIndice], 2));
        }

        if(AccXYZ[contIndice]!=0 && Azimuth[contIndice]!=0 && GyrXYZ[contIndice]!=0){
            if(contIndice==0){
                GyrEjeZ[contIndice] = Azimuth[contIndice]; //Guardo el primer dato del magnetómetro
            }
            contIndice++; //Esto se hace para que ningún sensor se quede sin guardar información en el vector
        }

        if (indiceInicio + ventanaTiempo + lateral_ventana <= contIndice && InicioAnalisis == true) {
            ventanaAccX = Arrays.copyOfRange(AccEjeX, (indiceInicio-lateral_ventana), (indiceInicio
                    + ventanaTiempo +lateral_ventana));
            ventanaAccY = Arrays.copyOfRange(AccEjeY, (indiceInicio-lateral_ventana), (indiceInicio + ventanaTiempo +lateral_ventana));
            ventanaAccZ = Arrays.copyOfRange(AccEjeZ, (indiceInicio-lateral_ventana), (indiceInicio + ventanaTiempo +lateral_ventana));
            ventanaAccXYZ = Arrays.copyOfRange(AccXYZ, (indiceInicio-lateral_ventana), (indiceInicio + ventanaTiempo +lateral_ventana)); //recoge datos de 1 segundo
            ventanaAzimuth = Arrays.copyOfRange(Azimuth, (indiceInicio-lateral_ventana), (indiceInicio + ventanaTiempo +lateral_ventana));
            ventanaGyrX = Arrays.copyOfRange(GyrEjeX, (indiceInicio-lateral_ventana), (indiceInicio + ventanaTiempo +lateral_ventana));
            ventanaGyrZ = Arrays.copyOfRange(GyrEjeZ, (indiceInicio-lateral_ventana), (indiceInicio + ventanaTiempo +lateral_ventana));
            ventanaGyrXYZ = Arrays.copyOfRange(GyrXYZ, (indiceInicio-lateral_ventana), (indiceInicio + ventanaTiempo +lateral_ventana));
            Tiempo_ventanaAccXYZ = Arrays.copyOfRange(TIEMPO, (indiceInicio-lateral_ventana), (indiceInicio + ventanaTiempo +lateral_ventana)); //copia la ventana de tiempo actual
            InicioAnalisis = false; //Termina de guardar datos en ventana actual
            InicioAnalisis2 = true; //Habilita el siguiente proceso, filtrado de señal
        }

        if(InicioAnalisis2==true){
            AccXYZfiltrada_90=filtroPasaBajas(ventanaAccXYZ,fc); //Filtra la señal
            AccXYZfiltrada = Arrays.copyOfRange(AccXYZfiltrada_90,lateral_ventana,(lateral_ventana+ventanaTiempo));
            ventanaGyrXYZ = Arrays.copyOfRange(ventanaGyrXYZ,lateral_ventana,(lateral_ventana+ventanaTiempo));
            //Función detección de actividad
            id_act_anterior = id_actividad;
            id_actividad = actividadActual(ventanaGyrX, ventanaAccY);
            if(id_actividad == 2 && id_act_anterior!=2){
                switch1.setChecked(true); //Texteo
                umbralPicos = 0.7;
                umbralPicos_sinFiltrar = 1.2;
                umbralValles = -0.4;
                umbralValles_sinFiltrar = -0.6;
            }
            if(id_actividad == 1 && id_act_anterior!=1){
                switch1.setChecked(false); //Balanceo
                umbralPicos = 0.7;
                umbralPicos_sinFiltrar = 1.2;
                umbralValles = -0.9;
                umbralValles_sinFiltrar = -1.2;
            }
            //Fin
            InicioAnalisis2 = false; //Termina proceso de filtrado de señal
            InicioAnalisis3 = true; //Habilita el proceso detección de cruces por cero
        }

        if(InicioAnalisis3==true){
            CrucesPorCeroAccXYZ=crucesPorCeroFiltro(AccXYZfiltrada_90,ventanaTiempo,lateral_ventana);
            CrucesPorCeroAccXYZ=Arrays.copyOfRange(CrucesPorCeroAccXYZ,lateral_ventana,(lateral_ventana+ventanaTiempo));
            CrucesPorCeroAccXYZ_sinFiltrar=crucesPorCero(ventanaAccXYZ);
            CrucesPorCeroAccXYZ_sinFiltrar=Arrays.copyOfRange(CrucesPorCeroAccXYZ_sinFiltrar,lateral_ventana,(lateral_ventana+ventanaTiempo));
            InicioAnalisis3 = false; //Termina el proceso de detección de cruces por cero
            InicioAnalisis4 = true; //Habilita el proceso de detección de picos
        }

        if(InicioAnalisis4==true){
            PicosAccXYZ=deteccionPicosFiltro(AccXYZfiltrada_90,umbralPicos,ventanaTiempo,lateral_ventana);
            PicosAccXYZ=Arrays.copyOfRange(PicosAccXYZ,lateral_ventana,(lateral_ventana+ventanaTiempo));
            PicosAccXYZ_sinFiltrar=deteccionPicos(ventanaAccXYZ,umbralPicos_sinFiltrar);
            PicosAccXYZ_sinFiltrar=Arrays.copyOfRange(PicosAccXYZ_sinFiltrar,lateral_ventana,(lateral_ventana+ventanaTiempo));
            InicioAnalisis4 = false; //Termina el proceso de detección de picos
            InicioAnalisis5 = true; //Habilita el proceso de detección de valles
        }

        if(InicioAnalisis5==true){
            VallesAccXYZ=deteccionVallesFiltro(AccXYZfiltrada_90,umbralValles,ventanaTiempo,lateral_ventana);
            VallesAccXYZ=Arrays.copyOfRange(VallesAccXYZ,lateral_ventana,(lateral_ventana+ventanaTiempo));
            VallesAccXYZ_sinFiltrar=deteccionValles(ventanaAccXYZ,umbralValles_sinFiltrar);
            VallesAccXYZ_sinFiltrar=Arrays.copyOfRange(VallesAccXYZ_sinFiltrar,lateral_ventana,(lateral_ventana+ventanaTiempo));
            InicioAnalisis5 = false; //Termina el proceso de detección de valles
            InicioAnalisis6 = true; //Habilita el proceso de unión de cruces, picos y valles
        }

        if(InicioAnalisis6==true){
            UnionCPVAccXYZ=unionCrucesPicosValles(CrucesPorCeroAccXYZ,PicosAccXYZ,VallesAccXYZ);
            UnionCPVAccXYZ_sinFiltrar=unionCrucesPicosValles(CrucesPorCeroAccXYZ_sinFiltrar,PicosAccXYZ_sinFiltrar,VallesAccXYZ_sinFiltrar);
            InicioAnalisis6 = false; //Termina el proceso de unión de cruces, picos y valles
            InicioAnalisis8 = true; //Habilita el proceso de eliminación de redundancia
        }

        if(InicioAnalisis8==true){
            Vcpv_PyV_emparejado=VcpvFiltradoOrganizadoDefinitivo(UnionCPVAccXYZ,UnionCPVAccXYZ_sinFiltrar);
            /*
            id_act_anterior = id_actividad;
            id_actividad = actividadActual(ventanaGyrX, ventanaAccY);
            if(id_actividad == 2 && id_act_anterior!=2){
                switch1.setChecked(true);
            }
            if(id_actividad == 1 && id_act_anterior!=1){
                switch1.setChecked(false);
            }
            //*/
            InicioAnalisis8 = false; //Termina el proceso de emparejamiento Vcpv
            InicioAnalisis9 = true; //Habilita el proceso de conteo de pasos
        }

        if(InicioAnalisis9==true){
            double [] ventanaAccXYZ_50 = Arrays.copyOfRange(ventanaAccXYZ,lateral_ventana,(lateral_ventana+ventanaTiempo));
            double [] Tiempo_ventanaAccXYZ_50 = Arrays.copyOfRange(Tiempo_ventanaAccXYZ,lateral_ventana,(lateral_ventana+ventanaTiempo));
            //Para imprimir id actividad
            //int promGyr = 0;
            //promGyr = actividadActual(ventanaGyrX, ventanaAccY);
            //imprimirX+=promGyr;
            //imprimirX+=", ";
            if(id_actividad==1){
                Matriz_general_conteo_pasos=conteoPasosYDistanciaBalanceo(Matriz_general_conteo_pasos,Vcpv_PyV_emparejado,ventanaAccXYZ_50,Tiempo_ventanaAccXYZ_50);
                Matriz_distancia_tiempos=matrizDistanciaTiempos(Matriz_general_conteo_pasos);
                Matriz_distancia_direccion=distanciaYdireccion(Matriz_distancia_tiempos,Tiempo_ventanaAccXYZ,ventanaAzimuth);
                //Matriz_distancia_direccion=distanciaYdireccion(Matriz_distancia_tiempos,Tiempo_ventanaAccXYZ,ventanaGyrZ, AnguloActual);
                //Después de calcular guardar el dato más reciente de azimuth
                for(int r=0; r<Matriz_distancia_direccion[0].length; r++){
                    if(Matriz_distancia_direccion[0][r]!=0){
                        MatDyD[0][contadorDyD+r]=Matriz_distancia_direccion[0][r];
                        MatDyD[1][contadorDyD+r]=Matriz_distancia_direccion[1][r];
                        AnguloActual=Matriz_distancia_direccion[1][r];
                        primer_valor_dif_cero = true;
                    }
                }
                if(primer_valor_dif_cero == true){
                    contadorDyD=contadorDyD+5;
                }
                MatXY=calcularRecorrido(MatDyD);
                MatXY_rotada=rotarGrafica(MatXY,205);

                //LÍNEAS PARA GRAFICAR
                int [] Vector_x_int = new int [MatXY_rotada[0].length];
                int [] Vector_y_int = new int [MatXY_rotada[0].length];
                for(int i=0; i<MatXY_rotada[0].length; i++){
                    Vector_x_int [i] = (int) (MatXY_rotada [0][i]*100);
                    Vector_y_int [i] = (int) (MatXY_rotada [1][i]*100);
                }
                graficar(Vector_x_int,Vector_y_int);
                //FIN DE GRÁFICA

                ///*
                imprimirX = "x=[";
                imprimirY = "y=[";
                for(int r=0; r<MatDyD[0].length; r++){
                    if(MatDyD[0][r]!=0){
                        imprimirX+=MatDyD[0][r];
                        imprimirX+=",";
                        imprimirY+=MatDyD[1][r];
                        imprimirY+=",";
                    }
                }
                //*/
                this.editTextTextMultiLine.setText(imprimirX+"\n"+imprimirY+"\nplot(x,y)");
            }
            if(id_actividad==2){
                Matriz_general_conteo_pasos=conteoPasosYDistanciaTexteando(Matriz_general_conteo_pasos,Vcpv_PyV_emparejado,ventanaAccXYZ_50,Tiempo_ventanaAccXYZ_50);
                Matriz_distancia_tiempos=matrizDistanciaTiempos(Matriz_general_conteo_pasos);
                Matriz_distancia_direccion=distanciaYdireccion(Matriz_distancia_tiempos,Tiempo_ventanaAccXYZ,ventanaAzimuth);
                //Matriz_distancia_direccion=distanciaYdireccion(Matriz_distancia_tiempos,Tiempo_ventanaAccXYZ,ventanaGyrZ, AnguloActual);
                for(int r=0; r<Matriz_distancia_direccion[0].length; r++){
                    if(Matriz_distancia_direccion[0][r]!=0){
                        MatDyD[0][contadorDyD+r]=Matriz_distancia_direccion[0][r];
                        MatDyD[1][contadorDyD+r]=Matriz_distancia_direccion[1][r];
                        AnguloActual=Matriz_distancia_direccion[1][r];
                        primer_valor_dif_cero = true;
                    }
                }
                if(primer_valor_dif_cero == true){
                    contadorDyD=contadorDyD+5;
                }
                MatXY=calcularRecorrido(MatDyD);
                MatXY_rotada=rotarGrafica(MatXY,205);

                //LÍNEAS PARA GRAFICAR
                int [] Vector_x_int = new int [MatXY_rotada[0].length];
                int [] Vector_y_int = new int [MatXY_rotada[0].length];
                for(int i=0; i<MatXY_rotada[0].length; i++){
                    Vector_x_int [i] = (int) (MatXY_rotada [0][i]*100);
                    Vector_y_int [i] = (int) (MatXY_rotada [1][i]*100);
                }
                graficar(Vector_x_int,Vector_y_int);
                //FIN DE GRÁFICA

                ///*
                imprimirX = "x=[";
                imprimirY = "y=[";
                for(int r=0; r<MatDyD[0].length; r++){
                    if(MatDyD[0][r]!=0){
                        imprimirX+=MatDyD[0][r];
                        imprimirX+=",";
                        imprimirY+=MatDyD[1][r];
                        imprimirY+=",";
                    }
                }
                //*/
                this.editTextTextMultiLine.setText(imprimirX+"\n"+imprimirY+"\nplot(x,y)");
            }

            this.textViewConteoPasos.setText(Math.round(Matriz_general_conteo_pasos[0][2]) + "");
            double metros = Math.round(Matriz_general_conteo_pasos[1][2]*100);
            metros = metros/100;
            this.textViewConteoDistancia.setText(metros + "m");
            InicioAnalisis9 = false; //Termina el proceso de conteo de pasos
            if(Detener==false){
                InicioAnalisis = true; //Repite el ciclo
                indiceInicio = indiceInicio + ventanaTiempo;
            }
            else if(Detener==true){
                InicioAnalisis = false; //Detiene el ciclo
            }
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        //No se utiliza
    }

    public void detenerRecoleccionAcc(View view){
        Detener = true;
        Toast.makeText(getApplicationContext(),"Recolección de datos detenida",Toast.LENGTH_LONG).show();
    }

    public void recogerMagAcc(View view){
        indiceInicio = contIndice;
        indiceInicioT = contIndice;
        InicioAnalisis = true;
        Detener = false;
        imprimirX = "x=[";
        imprimirY = "y=[";
        Toast.makeText(getApplicationContext(),"Recolección de datos iniciada",Toast.LENGTH_LONG).show();
    }

    public void reiniciarPasos(View view){
        if(Detener==true) {
            for (int t = 0; t <= 7; t++) { //Cada vez que se produce un cambio de actividad, se reinician los símbolos anteriores
                for (int g = 0; g <= 7; g++) {
                    Matriz_general_conteo_pasos[g][t] = 0;
                }
            }
            Matriz_general_conteo_pasos[2][2] = 0; //Trasantepenúltimo símbolo
            Matriz_general_conteo_pasos[2][3] = 0; //Antepenúltimo símbolo
            Matriz_general_conteo_pasos[1][2] = 0; //Distancia total
            Matriz_general_conteo_pasos[0][2] = 0; //Pasos totales
            this.textViewConteoPasos.setText("0");
            this.textViewConteoDistancia.setText("0m");
            this.editTextTextMultiLine.setText("Inicie otra prueba");
            //Reiniciar valores de matDyD
            contadorDyD = 0;
            primer_valor_dif_cero = false;
            for (int s = 0; s < MatDyD[0].length; s++) {
                MatDyD[0][s]=0;
                MatDyD[1][s]=0;
            }
            Toast.makeText(getApplicationContext(), "¡Reinicio!", Toast.LENGTH_LONG).show();
        }else{
            Toast.makeText(getApplicationContext(), "¡Primero debe detener!", Toast.LENGTH_LONG).show();
        }
    }

    /*
    public void establecerUmbrales(View view){
        double PcF = -1;
        double VcF = -1;
        double PsF = -1;
        double VsF = -1;
        double alt = -1;

        if(editTextNumberDecimal.getText().toString().trim().length() > 0){
            PcF = Double.parseDouble(editTextNumberDecimal.getText().toString());
        }
        else{
            Toast.makeText(getApplicationContext(),"Complete los valores de umbrales",Toast.LENGTH_LONG).show();
        }
        if(editTextNumberDecimal2.getText().toString().trim().length() > 0){
            VcF = Double.parseDouble(editTextNumberDecimal2.getText().toString());
        }
        else{
            Toast.makeText(getApplicationContext(),"Complete los valores de umbrales",Toast.LENGTH_LONG).show();
        }
        if(editTextNumberDecimal3.getText().toString().trim().length() > 0){
            PsF = Double.parseDouble(editTextNumberDecimal3.getText().toString());
        }
        else{
            Toast.makeText(getApplicationContext(),"Complete los valores de umbrales",Toast.LENGTH_LONG).show();
        }
        if(editTextNumberDecimal4.getText().toString().trim().length() > 0){
            VsF = Double.parseDouble(editTextNumberDecimal4.getText().toString());
        }
        else{
            Toast.makeText(getApplicationContext(),"Complete los valores de umbrales",Toast.LENGTH_LONG).show();
        }
        if(editTextNumberDecimalAltura.getText().toString().trim().length() > 0){
            alt = Double.parseDouble(editTextNumberDecimalAltura.getText().toString());
        }
        else{
            Toast.makeText(getApplicationContext(),"Complete el valor de la altura",Toast.LENGTH_LONG).show();
        }

        if(PcF==0 || VcF==0 || PsF==0 || VsF==0){
            Toast.makeText(getApplicationContext(),"Son necesarios valores de umbrales mayores que cero",Toast.LENGTH_LONG).show();
        }
        if(alt==0){
            Toast.makeText(getApplicationContext(),"Es necesaria una altura mayor que cero",Toast.LENGTH_LONG).show();
        }

        if(PcF>0 && VcF>0 && PsF>0 && VsF>0 && alt>0){
            umbralPicos = PcF;
            umbralValles = VcF*(-1);
            umbralPicos_sinFiltrar = PsF;
            umbralValles_sinFiltrar = VsF*(-1);
            altura = alt;

            AdminSQLiteOpenHelper admin = new AdminSQLiteOpenHelper(this,"administracion",null,1);
            SQLiteDatabase BaseDeDatos = admin.getWritableDatabase();
            ContentValues registro = new ContentValues();
            //codigo, umbralpsf, umbralvsf, umbralpcf, umbralvcf, altura
            registro.put("codigo",codigo);
            registro.put("umbralpsf",PsF);
            registro.put("umbralvsf",VsF);
            registro.put("umbralpcf",PcF);
            registro.put("umbralvcf",VcF);
            registro.put("altura",alt);
            //Método para buscar en la base de datos
            Cursor fila = BaseDeDatos.rawQuery("select umbralpsf, umbralvsf, umbralpcf, umbralvcf, altura from umbralesyaltura where codigo = "+codigo,null);
            if(fila.moveToFirst()){
                //Método para modificar
                int cantidad = BaseDeDatos.update("umbralesyaltura",registro,"codigo="+codigo,null);
                BaseDeDatos.close();
                if(cantidad == 1){
                    Toast.makeText(getApplicationContext(),"Base de datos ya creada: Valores modificados",Toast.LENGTH_LONG).show();
                }
            }else{
                //Método para registrar datos por primera vez
                BaseDeDatos.insert("umbralesyaltura",null,registro);
                BaseDeDatos.close();
                Toast.makeText(getApplicationContext(),"Base de datos creada: Valores almacenados",Toast.LENGTH_LONG).show();
            }
        }
    }
    */

    public void onclick(View view) {
        if (view.getId()==R.id.switch1){
            if(switch1.isChecked()){
                id_actividad = 2; //Texteando
                for(int t=0;t<=1;t++){ //Cada vez que se produce un cambio de actividad, se reinician los símbolos anteriores
                    for(int g=0;g<=7;g++){
                        Matriz_general_conteo_pasos[g][t]=0;
                    }
                }
                Matriz_general_conteo_pasos[2][2]=0; //Trasantepenúltimo símbolo
                Matriz_general_conteo_pasos[2][3]=0; //Antepenúltimo símbolo
                Toast.makeText(getApplicationContext(),"Modo texteando establecido",Toast.LENGTH_SHORT).show();
            }else{
                id_actividad = 1; //Balanceo
                for(int t=0;t<=1;t++){ //Cada vez que se produce un cambio de actividad, se reinician los símbolos anteriores
                    for(int g=0;g<=7;g++){
                        Matriz_general_conteo_pasos[g][t]=0;
                    }
                }
                Matriz_general_conteo_pasos[2][2]=0; //Trasantepenúltimo símbolo
                Matriz_general_conteo_pasos[2][3]=0; //Antepenúltimo símbolo
                Toast.makeText(getApplicationContext(),"Modo balanceo establecido",Toast.LENGTH_SHORT).show();
            }
        }
    }

    public static double[] filtroPasaBajas (double[] XYZ, int fc){
        //Transformada de Fourier en Tiempo Discreto
        int N = XYZ.length;
        double[] Vector_real_1 = new double [N];
        double[] Vector_imag_1 = new double [N];
        double[] Vector_real_2 = new double [N];
        double[] Vector_imag_2 = new double [N];
        double[][] Matriz_real_imag_3 = new double [2*N][N];
        double[] Vector_Xf_real = new double [N];
        double[] Vector_Xf_imag = new double [N];

        for (int k=0;k<=N-1;k++){
            for (int n=0;n<=N-1;n++){
                Vector_real_1[n]=Math.cos(2*(Math.PI)*k*n/N); //Fórmula Transformada de Fourier en Tiempo Discreto
                Vector_imag_1[n]=(-1)*(Math.sin(2*(Math.PI)*k*n/N));
            }
            for (int n=0;n<=N-1;n++){
                Vector_real_2[n]=XYZ[n]*Vector_real_1[n]; //Operación .*XYZ
                Vector_imag_2[n]=XYZ[n]*Vector_imag_1[n];
            }
            for (int n=0;n<=N-1;n++){
                Matriz_real_imag_3[(k*2)][n]=Vector_real_2[n]; //Guardar reales e imaginarios en una matriz
                Matriz_real_imag_3[(k*2)+1][n]=Vector_imag_2[n];
            }
            for (int n=0;n<=N-1;n++){
                Vector_Xf_real[k]=Vector_Xf_real[k]+Matriz_real_imag_3[(k*2)][n]; //Suma de los productos de la matriz
                Vector_Xf_imag[k]=Vector_Xf_imag[k]+Matriz_real_imag_3[(k*2)+1][n];
            }
        }

        //Eliminación de componentes en frecuencia
        for (int n=fc;n<=N-1-fc;n++){
            Vector_Xf_real[n]=0;
            Vector_Xf_imag[n]=0;
        }

        //Transformada Inversa de Fourier en Tiempo Discreto
        double[] Vector_real_4 = new double [N];
        double[] Vector_imag_4 = new double [N];
        double[][] Matriz_real_imag_5 = new double [4][N];
        double[][] Matriz_real_imag_6 = new double [2*N][N];
        double[][] Matriz_real_imag_7 = new double [N][N];
        double[] Xt_filtrada_real = new double [N];

        for (int k=0;k<=N-1;k++){
            for (int n=0;n<=N-1;n++){
                Vector_real_4[n]=(Math.cos(2*(Math.PI)*k*n/N))/N; //Fórmula Transformada Inversa de Fourier en Tiempo Discreto
                Vector_imag_4[n]=(Math.sin(2*(Math.PI)*k*n/N))/N;
            }
            for (int n=0;n<=N-1;n++){
                Matriz_real_imag_5[0][n]=Vector_Xf_real[n]*Vector_real_4[n]; //Real1*Real2
                Matriz_real_imag_5[1][n]=Vector_Xf_real[n]*Vector_imag_4[n]; //Real1*Imag2 ->Descartados
                Matriz_real_imag_5[2][n]=Vector_Xf_imag[n]*Vector_real_4[n]; //Imag1*Real2 ->Descartados
                Matriz_real_imag_5[3][n]=(Vector_Xf_imag[n]*Vector_imag_4[n])*(-1); //Imag1*Imag2
            }
            for (int n=0;n<=N-1;n++){
                Matriz_real_imag_6[(k*2)][n]=Matriz_real_imag_5[0][n]; //Guardar reales en una sola matriz
                Matriz_real_imag_6[(k*2)+1][n]=Matriz_real_imag_5[3][n];
            }
            for (int n=0;n<=N-1;n++){
                Matriz_real_imag_7[k][n]=Matriz_real_imag_6[(k*2)][n]+Matriz_real_imag_6[(k*2)+1][n]; //Suma de reales
            }
            for (int n=0;n<=N-1;n++){
                Xt_filtrada_real[k]=(Xt_filtrada_real[k])+(Matriz_real_imag_7[k][n]); //Suma de los productos de la matriz
            }
        }

        return Xt_filtrada_real;
    }

    public static double[] crucesPorCero (double[] SenalFiltrada){
        //Función para detectar los cruces por cero
        int N = SenalFiltrada.length;
        double[] Vector_crucesPorCero = new double [N];

        for (int n=0;n<=N-1;n++){
            if((n>0) && (SenalFiltrada[n-1]*SenalFiltrada[n]<0)){
                Vector_crucesPorCero[n]=1; //Uno indica que hubo cruce por cero
            }
        }

        return Vector_crucesPorCero;
    }

    public static double[] crucesPorCeroFiltro (double[] SenalFiltrada, int ventana, int lateral){
        //Función para detectar los cruces por cero
        int N = SenalFiltrada.length;
        double[] Vector_crucesPorCero = new double [N];

        for (int n=0;n<=N-1;n++){
            if((n>0) && (SenalFiltrada[n-1]*SenalFiltrada[n]<0)){
                Vector_crucesPorCero[n]=1; //Uno indica que hubo cruce por cero
            }
        }

        //Control de excepciones de los bordes
        if(Vector_crucesPorCero[lateral-1]==1){
            Vector_crucesPorCero[lateral-1]=0;
            Vector_crucesPorCero[lateral]=1;
        }
        if(Vector_crucesPorCero[ventana+lateral]==1){
            Vector_crucesPorCero[ventana+lateral]=0;
            Vector_crucesPorCero[ventana+lateral-1]=1;
        }

        return Vector_crucesPorCero;
    }

    public static double[] deteccionPicos (double[] SenalFiltrada, double umbral){
        //Función para detectar picos según umbral de entrada definido por actividad del usuario
        int N = SenalFiltrada.length;
        int bandera = 0; //Bandera de pico encontrado
        double[] Vector_senal_positiva = new double [N];
        double[] Vector_picos_senal = new double [N];

        //Aplicación del umbral
        for (int n=0;n<=N-1;n++){
            if(SenalFiltrada[n]>umbral){
                Vector_senal_positiva[n]=SenalFiltrada[n];
            }
            else if(SenalFiltrada[n]<=umbral){
                Vector_senal_positiva[n]=0;
            }
        }

        //Detección de picos
        for (int n=0;n<=N-1;n++){
            if(n==0){
                Vector_picos_senal[n]=0; //Cero indica que no hubo pico
            }
            else if((n>0) && (Vector_senal_positiva[n-1]<Vector_senal_positiva[n])){
                bandera=0;
            }
            else if((Vector_senal_positiva[n-1]!=0) && (bandera==0)){
                Vector_picos_senal[n-1]=1; //Uno indica que hubo pico
                bandera=1;
            }
        }

        return Vector_picos_senal;
    }

    public static double[] deteccionPicosFiltro (double[] SenalFiltrada, double umbral, int ventana, int lateral){
        //Función para detectar picos según umbral de entrada definido por actividad del usuario
        int N = SenalFiltrada.length;
        int bandera = 0; //Bandera de pico encontrado
        double[] Vector_senal_positiva = new double [N];
        double[] Vector_picos_senal = new double [N];

        //Aplicación del umbral
        for (int n=0;n<=N-1;n++){
            if(SenalFiltrada[n]>umbral){
                Vector_senal_positiva[n]=SenalFiltrada[n];
            }
            else if(SenalFiltrada[n]<=umbral){
                Vector_senal_positiva[n]=0;
            }
        }

        //Detección de picos
        for (int n=0;n<=N-1;n++){
            if(n==0){
                Vector_picos_senal[n]=0; //Cero indica que no hubo pico
            }
            else if((n>0) && (Vector_senal_positiva[n-1]<Vector_senal_positiva[n])){
                bandera=0;
            }
            else if((Vector_senal_positiva[n-1]!=0) && (bandera==0)){
                Vector_picos_senal[n-1]=1; //Uno indica que hubo pico
                bandera=1;
            }
        }

        //Control de excepciones de los bordes
        if(Vector_picos_senal[lateral-1]==1){
            Vector_picos_senal[lateral-1]=0;
            Vector_picos_senal[lateral]=1;
        }
        if(Vector_picos_senal[ventana+lateral]==1){
            Vector_picos_senal[ventana+lateral]=0;
            Vector_picos_senal[ventana+lateral-1]=1;
        }

        return Vector_picos_senal;
    }

    public static double[] deteccionValles (double[] SenalFiltrada, double umbralValles){
        //Función para detectar picos según umbral de entrada definido por actividad del usuario
        int N = SenalFiltrada.length;
        int bandera = 0; //Bandera de pico encontrado
        double[] Vector_senal_negativa = new double [N];
        double[] Vector_valles_senal = new double [N];

        //Aplicación del umbral
        for (int n=0;n<=N-1;n++){
            if(SenalFiltrada[n]<umbralValles){
                Vector_senal_negativa[n]=SenalFiltrada[n];
            }
            else if(SenalFiltrada[n]>=umbralValles){
                Vector_senal_negativa[n]=0;
            }
        }

        //Detección de valles
        for (int n=0;n<=N-1;n++){
            if(n==0){
                Vector_valles_senal[n]=0; //Cero indica que no hubo valle
            }
            else if((n>0) && (Vector_senal_negativa[n-1]>Vector_senal_negativa[n])){
                bandera=0;
            }
            else if((Vector_senal_negativa[n-1]!=0) && (bandera==0)){
                Vector_valles_senal[n-1]=1; //Uno indica que hubo valle
                bandera=1;
            }
        }

        return Vector_valles_senal;
    }

    public static double[] deteccionVallesFiltro (double[] SenalFiltrada, double umbralValles, int ventana, int lateral){
        //Función para detectar picos según umbral de entrada definido por actividad del usuario
        int N = SenalFiltrada.length;
        int bandera = 0; //Bandera de pico encontrado
        double[] Vector_senal_negativa = new double [N];
        double[] Vector_valles_senal = new double [N];

        //Aplicación del umbral
        for (int n=0;n<=N-1;n++){
            if(SenalFiltrada[n]<umbralValles){
                Vector_senal_negativa[n]=SenalFiltrada[n];
            }
            else if(SenalFiltrada[n]>=umbralValles){
                Vector_senal_negativa[n]=0;
            }
        }

        //Detección de valles
        for (int n=0;n<=N-1;n++){
            if(n==0){
                Vector_valles_senal[n]=0; //Cero indica que no hubo valle
            }
            else if((n>0) && (Vector_senal_negativa[n-1]>Vector_senal_negativa[n])){
                bandera=0;
            }
            else if((Vector_senal_negativa[n-1]!=0) && (bandera==0)){
                Vector_valles_senal[n-1]=1; //Uno indica que hubo valle
                bandera=1;
            }
        }

        //Control de excepciones de los bordes
        if(Vector_valles_senal[lateral-1]==1){
            Vector_valles_senal[lateral-1]=0;
            Vector_valles_senal[lateral]=1;
        }
        if(Vector_valles_senal[ventana+lateral]==1){
            Vector_valles_senal[ventana+lateral]=0;
            Vector_valles_senal[ventana+lateral-1]=1;
        }

        return Vector_valles_senal;
    }

    public static double[] unionCrucesPicosValles (double[] cruces, double[] picos, double[] valles){
        //Función para unir en un solo vector los valores de cruces, picos y valles
        //Convenciones:
        //Cruces = 1; Picos = 2; Valles = 3;
        int N = cruces.length;
        double[] Vector_CPV = new double [N];

        for (int n=0;n<=N-1;n++){
            if(cruces[n]==1){
                Vector_CPV[n]=1;
            }
        }
        for (int n=0;n<=N-1;n++){
            if(picos[n]==1){
                Vector_CPV[n]=2;
            }
        }
        for (int n=0;n<=N-1;n++){
            if(valles[n]==1){
                Vector_CPV[n]=3;
            }
        }

        return Vector_CPV;
    }

    public static double[] VcpvFiltradoOrganizadoDefinitivo (double [] VcpvFiltrado_sinR, double [] VcpvOriginal){
        //Función para asociar el vector CPV sin redundancia al vector CPV original para reacomodar sus símbolos
        //en las posiciones correctas
        //Solo asocia picos y valles. Los cruces por cero se dejan intactos, ya que representan un promedio
        int N = VcpvOriginal.length;
        double[] VectorCPV_definitivo = new double [N];
        for (int n=0;n<=N-1;n++){
            if(VcpvFiltrado_sinR[n]==1){
                VectorCPV_definitivo[n]=VcpvFiltrado_sinR[n]; //Traspasa sin modificar los cruces por cero
            }
        }
        for (int n=0;n<=N-1;n++){
            if(VcpvFiltrado_sinR[n]==2){
                if(VcpvOriginal[n]==2){
                    VectorCPV_definitivo[n]=VcpvOriginal[n]; //Si encuentra el pico en el otro vector en la misma posición termina el ciclo guardando el dato
                }
                else{ //Si no encuentra el pico en la misma posición, empiezo a analizar vecindad
                    int vecindad = 1;
                    boolean vecindad_hallada = false;
                    while(vecindad_hallada == false){
                        double[] VectorCPV_MasVecindad = new double [vecindad+N+vecindad];
                        for(int i=0;i<=N-1;i++){
                            VectorCPV_MasVecindad[i+vecindad]=VcpvOriginal[i];
                        }
                        if(VectorCPV_MasVecindad[n+vecindad+vecindad]==2){
                            VectorCPV_definitivo[n+vecindad]=VectorCPV_MasVecindad[n+vecindad+vecindad]; //Analiza el primer dato por la derecha
                            vecindad_hallada = true;
                        }
                        else if(VectorCPV_MasVecindad[n]==2){
                            VectorCPV_definitivo[n-vecindad]=VectorCPV_MasVecindad[n]; //Analiza el primer dato por la izquierda
                            vecindad_hallada = true;
                        }
                        else{
                            vecindad++;
                        }
                        if(vecindad>=10){
                            vecindad_hallada = true;
                        }
                    }
                }
            }
        }
        for (int n=0;n<=N-1;n++){
            if(VcpvFiltrado_sinR[n]==3){
                if(VcpvOriginal[n]==3){
                    VectorCPV_definitivo[n]=VcpvOriginal[n]; //Si encuentra el valle en el otro vector en la misma posición termina el ciclo guardando el dato
                }
                else{ //Si no encuentra el valle en la misma posición, empiezo a analizar vecindad
                    int vecindad = 1;
                    boolean vecindad_hallada = false;
                    while(vecindad_hallada == false){
                        double[] VectorCPV_MasVecindad = new double [vecindad+N+vecindad];
                        for(int i=0;i<=N-1;i++){
                            VectorCPV_MasVecindad[i+vecindad]=VcpvOriginal[i];
                        }
                        if(VectorCPV_MasVecindad[n+vecindad+vecindad]==3){
                            VectorCPV_definitivo[n+vecindad]=VectorCPV_MasVecindad[n+vecindad+vecindad]; //Analiza el primer dato por la derecha
                            vecindad_hallada = true;
                        }
                        else if(VectorCPV_MasVecindad[n]==3){
                            VectorCPV_definitivo[n-vecindad]=VectorCPV_MasVecindad[n]; //Analiza el primer dato por la izquierda
                            vecindad_hallada = true;
                        }
                        else{
                            vecindad++;
                        }
                        if(vecindad>=10){
                            vecindad_hallada = true;
                        }
                    }
                }
            }
        }

        return VectorCPV_definitivo;
    }

    public static double[][] conteoPasosYDistanciaBalanceo (double [][] Matriz_general, double [] Vcpv_definitivo, double [] XYZ, double [] tiempo){
        int N = Vcpv_definitivo.length;
        double [][] Matriz_general_fx = new double [8][8];
        Matriz_general_fx[0][2] = Matriz_general[0][2]; //Guarda total pasos desde anteriores análisis
        Matriz_general_fx[1][2] = Matriz_general[1][2]; //Guarda la distancia total recorrida hasta el momento
        double [] Valores_K = {0.4158,0.3909}; //Constantes pico, pico-valle. Futuramente dato entrante calculado desde otra función con un data set
        double [][] Matriz_dato_mag_extendida = new double [4][N+2]; //Extendida porque se le agregan dos datos anteriores, si clasifican
        //Fila 1: datos. Fila 2: distancias. Fila 3: magnitudes. Fila 4: tiempos.

        //Unión de los dos datos anteriores con los datos de la ventana actual
        Matriz_dato_mag_extendida[0][0]=Matriz_general[0][0]; //Traspaso penúltimo dato
        Matriz_dato_mag_extendida[0][1]=Matriz_general[0][1]; //Traspaso último dato
        Matriz_dato_mag_extendida[1][0]=Matriz_general[1][0]*(-1); //Traspaso distancia penúltimo dato
        Matriz_dato_mag_extendida[1][1]=Matriz_general[1][1]*(-1); //Traspaso distancia último dato
        Matriz_dato_mag_extendida[2][0]=Matriz_general[2][0]; //Traspaso magnitud del penúltimo dato
        Matriz_dato_mag_extendida[2][1]=Matriz_general[2][1]; //Traspaso magnitud del último dato
        Matriz_dato_mag_extendida[3][0]=Matriz_general[3][0]; //Traspaso tiempo del penúltimo dato
        Matriz_dato_mag_extendida[3][1]=Matriz_general[3][1]; //Traspaso tiempo del último dato
        for(int n=2;n<Matriz_dato_mag_extendida[0].length;n++){
            Matriz_dato_mag_extendida[0][n]=Vcpv_definitivo[n-2]; //Uno los dos datos anteriores con la ventana actual
        }
        for(int n=2;n<Matriz_dato_mag_extendida[0].length;n++){
            Matriz_dato_mag_extendida[1][n]=n-2; //Uno las distancias de los dos datos anteriores con los de la ventana actual
        }
        for(int n=2;n<Matriz_dato_mag_extendida[0].length;n++){
            if(Vcpv_definitivo[n-2]>0){
                Matriz_dato_mag_extendida[2][n]=XYZ[n-2]; //Uno las magnitudes de los dos datos anteriores con los de la ventana actual
            }
        }
        for(int n=2;n<Matriz_dato_mag_extendida[0].length;n++){
            if(Vcpv_definitivo[n-2]>0){
                Matriz_dato_mag_extendida[3][n]=tiempo[n-2]; //Uno los tiempos de los dos datos anteriores con los de la ventana actual
            }
        }

        //Análisis de la secuencia para contar y acumular pasos, acumular distancias y añade pasos individuales con su respectiva distancia
        double [] Matriz_analizable1 = new double [Matriz_dato_mag_extendida[0].length]; //Datos
        double [] Matriz_analizable2 = new double [Matriz_dato_mag_extendida[0].length]; //Distancias
        double [] Matriz_analizable3 = new double [Matriz_dato_mag_extendida[0].length]; //Magnitudes
        double [] Matriz_analizable4 = new double [Matriz_dato_mag_extendida[0].length]; //Tiempos
        double [] Matriz_analizable1_acortada = new double [Matriz_dato_mag_extendida[0].length];
        double [] Matriz_analizable2_acortada = new double [Matriz_dato_mag_extendida[0].length];
        double [] Matriz_analizable3_acortada = new double [Matriz_dato_mag_extendida[0].length];
        double [] Matriz_analizable4_acortada = new double [Matriz_dato_mag_extendida[0].length];
        int contador = 0;
        for(int n=0;n<Matriz_dato_mag_extendida[0].length;n++){
            if(Matriz_dato_mag_extendida[0][n]>0){ //Elimina los ceros intermedios para que sea más fácil trabajar la secuencia
                Matriz_analizable1[contador]=Matriz_dato_mag_extendida[0][n];
                Matriz_analizable2[contador]=Matriz_dato_mag_extendida[1][n];
                Matriz_analizable3[contador]=Matriz_dato_mag_extendida[2][n];
                Matriz_analizable4[contador]=Matriz_dato_mag_extendida[3][n];
                contador++;
            }
        }
        if(contador<4){ //Si hay 0,1,2 o 3 datos, acorta el vector a 3 posiciones
            Matriz_analizable1_acortada = Arrays.copyOfRange(Matriz_analizable1,0,3);
            Matriz_analizable2_acortada = Arrays.copyOfRange(Matriz_analizable2,0,3);
            Matriz_analizable3_acortada = Arrays.copyOfRange(Matriz_analizable3,0,3);
            Matriz_analizable4_acortada = Arrays.copyOfRange(Matriz_analizable4,0,3);
        }
        else if(contador>=4){ //Si hay más de 4 datos, crea el vector de la longitud contador
            Matriz_analizable1_acortada = Arrays.copyOfRange(Matriz_analizable1,0,contador);
            Matriz_analizable2_acortada = Arrays.copyOfRange(Matriz_analizable2,0,contador);
            Matriz_analizable3_acortada = Arrays.copyOfRange(Matriz_analizable3,0,contador);
            Matriz_analizable4_acortada = Arrays.copyOfRange(Matriz_analizable4,0,contador);
        } //Guarda únicamente los datos, sus distancias, sus magnitudes y tiempos

        //Genera una matriz que reúne cada dato con sus dos siguientes en filas
        int filasM = 0;
        if(Matriz_analizable1_acortada.length<4){ //Si hay 3 datos o menos, solo es necesaria una fila
            filasM = 1;
        }
        else if (Matriz_analizable1_acortada.length>=4){ //Si hay más de 3 datos, son necesarias (#datos - 2)
            filasM = Matriz_analizable1_acortada.length-2;
        }
        double [][] M_tripleta1 = new double [filasM][3]; //Datos
        double [][] M_tripleta2 = new double [filasM][3]; //Distancias
        double [][] M_tripleta3 = new double [filasM][3]; //Magnitudes
        double [][] M_tripleta4 = new double [filasM][3]; //Tiempos
        int aumentador = 0;
        if(filasM>1){ //Si hay más de una fila, crea los conjuntos de tres con los datos consecutivos
            for (int q=0;q<filasM;q++){
                for (int w=0;w<3;w++){
                    aumentador++;
                    M_tripleta1[q][w]=Matriz_analizable1_acortada[aumentador-1];
                    M_tripleta2[q][w]=Matriz_analizable2_acortada[aumentador-1];
                    M_tripleta3[q][w]=Matriz_analizable3_acortada[aumentador-1];
                    M_tripleta4[q][w]=Matriz_analizable4_acortada[aumentador-1];
                }
                aumentador=aumentador-2;
            }
        }
        else if(filasM==1){ //Si hay solo una fila, crea un único conjunto de tres con los datos consecutivos
            for (int q=0;q<3;q++){
                M_tripleta1[0][q]=Matriz_analizable1_acortada[q];
                M_tripleta2[0][q]=Matriz_analizable2_acortada[q];
                M_tripleta3[0][q]=Matriz_analizable3_acortada[q];
                M_tripleta4[0][q]=Matriz_analizable4_acortada[q];
            }
        }

        //Recorre cada fila de las matrices analizando inicio de paso pico y secuencias 2-1-3 y 3-1-2,
        //mientras tiene en cuenta una distancia coherente, calculando el número acumulado de pasos, calculando y
        //acumulando la distancia actual recorrida, y agregando al vector de salida los pasos individuales con
        //sus respectivas distancias en metros.
        double [] copia_datos_matriz_extendida = new double [Matriz_dato_mag_extendida[0].length];
        for(int n=2;n<Matriz_dato_mag_extendida[0].length;n++){
            copia_datos_matriz_extendida[n]=Matriz_dato_mag_extendida[0][n];
        } //Crea una copia de respaldo para manipular en el siguiente proceso en donde posiblemente se eliminarán datos
        int dismi = 1;
        int conteo = 0;
        for (int n=Matriz_dato_mag_extendida[0].length-1;n>=0;n--){
            if(copia_datos_matriz_extendida[n]>0){
                conteo++;
            }
            if(copia_datos_matriz_extendida[n]>0 && dismi>-1 && conteo>=3){
                Matriz_general_fx[2][2+dismi]=Matriz_dato_mag_extendida[0][n];
                dismi--;
            } //Guarda el antepenúltimo y trasantepenúltimo dato
        }
        int cont = 1;
        for (int e=0;e<filasM;e++){
            //INICIO DE PASO CON PICO
            if(M_tripleta1[e][0]==1 && M_tripleta1[e][1]==2 && M_tripleta1[e][2]==1){
                boolean inicio_paso_izq = true; //Inicia de forma "optimista" asegurando el paso,
                boolean entrada_izq = false; //pero puede cambiar si cumple con los siguientes análisis
                if(e>0){ //Analiza si hay secuencia 3-1-2 por la izquierda
                    entrada_izq = true;
                    if(M_tripleta1[e-1][0]==3 && M_tripleta1[e-1][1]==1 && M_tripleta1[e-1][2]==2){
                        inicio_paso_izq = false; //Lo establece en falso porque encontró una secuencia completa, perteneciente a un caminata
                    }
                }
                if(entrada_izq==false){
                    //Si entra a este if es porque no pudo analizar la izquierda de la secuencia 1-2-1
                    if(Matriz_general[2][3]==1 || Matriz_general[2][3]==0){
                        if(Matriz_general[2][2]==1 || Matriz_general[2][2]==0){ //|| Matriz_general[2][2]==3
                            //Si encuentra un cruce por cero en los datos antepenúltimo y trasantepenúltimo, es porque es un paso de inicio
                            double distancia_paso = Valores_K[0]*Math.sqrt(Math.sqrt(Math.abs(M_tripleta3[e][1])));
                            Matriz_general_fx[0][2]=Matriz_general_fx[0][2]+1;
                            Matriz_general_fx[1][2]=Matriz_general_fx[1][2]+distancia_paso;
                            Matriz_general_fx[0][cont+2]=cont;
                            Matriz_general_fx[1][cont+2]=distancia_paso;
                            Matriz_general_fx[3][cont+2]=M_tripleta4[e][0]; //Tiempo inicio paso
                            Matriz_general_fx[4][cont+2]=M_tripleta4[e][2]; //Tiempo final paso
                            cont++;
                        }
                    }
                }
                if(inicio_paso_izq==true && entrada_izq==true){
                    //Si entra a este if es porque pudo analizar la izquierda y siguió siendo true
                    //Entonces representa un paso de inicio
                    double distancia_paso = Valores_K[0]*Math.sqrt(Math.sqrt(Math.abs(M_tripleta3[e][1])));
                    Matriz_general_fx[0][2]=Matriz_general_fx[0][2]+1;
                    Matriz_general_fx[1][2]=Matriz_general_fx[1][2]+distancia_paso;
                    Matriz_general_fx[0][cont+2]=cont;
                    Matriz_general_fx[1][cont+2]=distancia_paso;
                    Matriz_general_fx[3][cont+2]=M_tripleta4[e][0]; //Tiempo inicio paso
                    Matriz_general_fx[4][cont+2]=M_tripleta4[e][2]; //Tiempo final paso
                    cont++;
                }
            }
            //INICIO DE PASO CON VALLE
            /*
            if(M_tripleta1[e][0]==1 && M_tripleta1[e][1]==3 && M_tripleta1[e][2]==1){
                boolean inicio_paso_izq = true; //Inicia de forma "optimista" asegurando el paso,
                boolean entrada_izq = false; //pero puede cambiar si cumple con los siguientes análisis
                if(e>0){ //Analiza si hay secuencia 2-1-3 por la izquierda
                    entrada_izq = true;
                    if(M_tripleta1[e-1][0]==2 && M_tripleta1[e-1][1]==1 && M_tripleta1[e-1][2]==3){
                        inicio_paso_izq = false; //Lo establece en falso porque encontró una secuencia completa, perteneciente a un caminata
                    }
                }
                if(entrada_izq==false){
                    //Si entra a este if es porque no pudo analizar la izquierda de la secuencia 1-3-1
                    if(Matriz_general[2][3]==1 || Matriz_general[2][3]==0){
                        if(Matriz_general[2][2]==1 || Matriz_general[2][2]==0){ //|| Matriz_general[2][2]==2
                            //Si encuentra un cruce por cero en los datos antepenúltimo y trasantepenúltimo, es porque es un paso de inicio
                            double distancia_paso = Valores_K[1]*Math.sqrt(Math.sqrt(Math.abs(M_tripleta3[e][1])));
                            Matriz_general_fx[0][2]=Matriz_general_fx[0][2]+1;
                            Matriz_general_fx[1][2]=Matriz_general_fx[1][2]+distancia_paso;
                            Matriz_general_fx[0][cont+2]=cont;
                            Matriz_general_fx[1][cont+2]=distancia_paso;
                            Matriz_general_fx[3][cont+2]=M_tripleta4[e][0]; //Tiempo inicio paso
                            Matriz_general_fx[4][cont+2]=M_tripleta4[e][4]; //Tiempo final paso
                            cont++;
                        }
                    }
                }
                if(inicio_paso_izq==true && entrada_izq==true){
                    //Si entra a este if es porque pudo analizar la izquierda y siguió siendo true
                    //Entonces representa un paso de inicio
                    double distancia_paso = Valores_K[1]*Math.sqrt(Math.sqrt(Math.abs(M_tripleta3[e][1])));
                    Matriz_general_fx[0][2]=Matriz_general_fx[0][2]+1;
                    Matriz_general_fx[1][2]=Matriz_general_fx[1][2]+distancia_paso;
                    Matriz_general_fx[0][cont+2]=cont;
                    Matriz_general_fx[1][cont+2]=distancia_paso;
                    Matriz_general_fx[3][cont+2]=M_tripleta4[e][0]; //Tiempo inicio paso
                    Matriz_general_fx[4][cont+2]=M_tripleta4[e][4]; //Tiempo final paso
                    cont++;
                }
            }
            */
            //SECUENCIA PICO-VALLE O COMPLETA
            if(M_tripleta1[e][0]==2 && M_tripleta1[e][1]==1 && M_tripleta1[e][2]==3){
                if(Matriz_general[6][2]!=0){
                    double dist_periodo=Math.abs(-Matriz_general[6][2]-M_tripleta2[e][2]);
                    if(dist_periodo>=64 && dist_periodo<=72){
                        Valores_K[1]=0.3659; //Lento
                    }else if(dist_periodo>=56 && dist_periodo<=63){
                        Valores_K[1]=0.3909; //Medio
                    }else if(dist_periodo>=40 && dist_periodo<=55){
                        Valores_K[1]=0.4158; //Rápido
                    }
                }
                double distancia_paso = Valores_K[1]*Math.sqrt(Math.sqrt(Math.abs(M_tripleta3[e][0]-M_tripleta3[e][2])));
                Matriz_general_fx[0][2]=Matriz_general_fx[0][2]+1;
                Matriz_general_fx[1][2]=Matriz_general_fx[1][2]+distancia_paso;
                Matriz_general_fx[0][cont+2]=cont;
                Matriz_general_fx[1][cont+2]=distancia_paso;
                Matriz_general_fx[3][cont+2]=M_tripleta4[e][0]; //Tiempo inicio paso
                Matriz_general_fx[4][cont+2]=M_tripleta4[e][2]; //Tiempo final paso
                cont++;
                if(M_tripleta2[e][1]>=0){
                    for(int r=Math.abs((int) M_tripleta2[e][1]);r>=0;r--){
                        copia_datos_matriz_extendida[r+2]=0;
                    }
                }
            }
            //SECUENCIA VALLE-PICO O COMPLETA
            if(M_tripleta1[e][0]==3 && M_tripleta1[e][1]==1 && M_tripleta1[e][2]==2){
                if(Matriz_general[6][2]!=0){
                    double dist_periodo=Math.abs(-Matriz_general[6][2]-M_tripleta2[e][0]);
                    if(dist_periodo>=64 && dist_periodo<=72){
                        Valores_K[1]=0.3659; //Lento
                    }else if(dist_periodo>=56 && dist_periodo<=63){
                        Valores_K[1]=0.3909; //Medio
                    }else if(dist_periodo>=40 && dist_periodo<=55){
                        Valores_K[1]=0.4158; //Rápido
                    }
                }
                double distancia_paso = Valores_K[1]*Math.sqrt(Math.sqrt(Math.abs(M_tripleta3[e][2]-M_tripleta3[e][0])));
                Matriz_general_fx[0][2]=Matriz_general_fx[0][2]+1;
                Matriz_general_fx[1][2]=Matriz_general_fx[1][2]+distancia_paso;
                Matriz_general_fx[0][cont+2]=cont;
                Matriz_general_fx[1][cont+2]=distancia_paso;
                Matriz_general_fx[3][cont+2]=M_tripleta4[e][0]; //Tiempo inicio paso
                Matriz_general_fx[4][cont+2]=M_tripleta4[e][2]; //Tiempo final paso
                cont++;
                if(M_tripleta2[e][1]>=0){
                    for(int r=Math.abs((int) M_tripleta2[e][1]);r>=0;r--){
                        copia_datos_matriz_extendida[r+2]=0;
                    }
                }
            }
        }

        //Guarda los dos últimos datos encontrados en la ventana actual para pasarlos a la siguiente
        //solamente pasa los datos no analizados
        int disminuidor = 1;
        boolean ultimo_valle = false;
        for (int n=Matriz_dato_mag_extendida[0].length-1;n>=0;n--){ //Encuentra la distancia del último valle
            if(Matriz_dato_mag_extendida[0][n]==3 && ultimo_valle==false){
                Matriz_general_fx[6][2]=N-Matriz_dato_mag_extendida[1][n];
                ultimo_valle = true;
            }
        }
        for (int n=Matriz_dato_mag_extendida[0].length-1;n>=0;n--){
            if(copia_datos_matriz_extendida[n]>0 && disminuidor>-1){
                Matriz_general_fx[0][disminuidor]=Matriz_dato_mag_extendida[0][n];
                Matriz_general_fx[1][disminuidor]=N-Matriz_dato_mag_extendida[1][n];
                Matriz_general_fx[2][disminuidor]=Matriz_dato_mag_extendida[2][n];
                Matriz_general_fx[3][disminuidor]=Matriz_dato_mag_extendida[3][n];
                disminuidor--;
            }
        }

        return Matriz_general_fx;
    }

    public static double[][] conteoPasosYDistanciaTexteando (double [][] Matriz_general, double [] Vcpv_definitivo, double [] XYZ, double [] tiempo){
        int N = Vcpv_definitivo.length;
        double [][] Matriz_general_fx = new double [8][8];
        Matriz_general_fx[0][2] = Matriz_general[0][2]; //Guarda total pasos desde anteriores análisis
        Matriz_general_fx[1][2] = Matriz_general[1][2]; //Guarda la distancia total recorrida hasta el momento
        Matriz_general_fx[7][2] = Matriz_general[7][2]; //Guarda la racha de paso hasta el momento
        double Valor_K = 0.4081; //Valor promedio por defecto. Futuramente dato entrante calculado desde otra función con un data set
        double [][] Matriz_dato_mag_extendida = new double [4][N+4]; //Extendida porque se le agregan cuatro datos anteriores, si clasifican
        //Fila 1: datos. Fila 2: distancias. Fila 3: magnitudes. Fila 4: tiempos.

        //Unión de los cuatro datos anteriores con los datos de la ventana actual
        Matriz_dato_mag_extendida[0][0]=Matriz_general[4][0]; //Traspaso trasantepenúltimo dato
        Matriz_dato_mag_extendida[0][1]=Matriz_general[4][1]; //Traspaso antepenúltimo dato
        Matriz_dato_mag_extendida[0][2]=Matriz_general[0][0]; //Traspaso penúltimo dato
        Matriz_dato_mag_extendida[0][3]=Matriz_general[0][1]; //Traspaso último dato

        Matriz_dato_mag_extendida[1][0]=Matriz_general[5][0]*(-1); //Traspaso distancia trasantepenúltimo dato
        Matriz_dato_mag_extendida[1][1]=Matriz_general[5][1]*(-1); //Traspaso distancia antepenúltimo dato
        Matriz_dato_mag_extendida[1][2]=Matriz_general[1][0]*(-1); //Traspaso distancia penúltimo dato
        Matriz_dato_mag_extendida[1][3]=Matriz_general[1][1]*(-1); //Traspaso distancia último dato

        Matriz_dato_mag_extendida[2][0]=Matriz_general[6][0]; //Traspaso magnitud trasantepenúltimo dato
        Matriz_dato_mag_extendida[2][1]=Matriz_general[6][1]; //Traspaso magnitud antepenúltimo dato
        Matriz_dato_mag_extendida[2][2]=Matriz_general[2][0]; //Traspaso magnitud del penúltimo dato
        Matriz_dato_mag_extendida[2][3]=Matriz_general[2][1]; //Traspaso magnitud del último dato

        Matriz_dato_mag_extendida[3][0]=Matriz_general[7][0]; //Traspaso tiempo trasantepenúltimo dato
        Matriz_dato_mag_extendida[3][1]=Matriz_general[7][1]; //Traspaso tiempo antepenúltimo dato
        Matriz_dato_mag_extendida[3][2]=Matriz_general[3][0]; //Traspaso tiempo del penúltimo dato
        Matriz_dato_mag_extendida[3][3]=Matriz_general[3][1]; //Traspaso tiempo del último dato

        for(int n=4;n<Matriz_dato_mag_extendida[0].length;n++){
            Matriz_dato_mag_extendida[0][n]=Vcpv_definitivo[n-4]; //Uno los cuatro datos anteriores con la ventana actual
        }
        for(int n=4;n<Matriz_dato_mag_extendida[0].length;n++){
            Matriz_dato_mag_extendida[1][n]=n-4; //Uno las distancias de los cuatro datos anteriores con los de la ventana actual
        }
        for(int n=4;n<Matriz_dato_mag_extendida[0].length;n++){
            if(Vcpv_definitivo[n-4]>0){
                Matriz_dato_mag_extendida[2][n]=XYZ[n-4]; //Uno las magnitudes de los cuatro datos anteriores con los de la ventana actual
            }
        }
        for(int n=4;n<Matriz_dato_mag_extendida[0].length;n++){
            if(Vcpv_definitivo[n-4]>0){
                Matriz_dato_mag_extendida[3][n]=tiempo[n-4]; //Uno los tiempos de los cuatro datos anteriores con los de la ventana actual
            }
        }

        //Control de excepciones de entrada de símbolos repetidos consecutivos
        boolean encontrado = false;
        double primer_simbolo = 0;
        for(int n=4;n<Matriz_dato_mag_extendida[0].length;n++){
            if(Matriz_dato_mag_extendida[0][n]>0 && encontrado == false){
                primer_simbolo = Matriz_dato_mag_extendida[0][n];
                encontrado = true;
            }
        }
        if(Matriz_dato_mag_extendida[0][3]==primer_simbolo){
            Matriz_dato_mag_extendida[0][3]=0;
            Matriz_dato_mag_extendida[1][3]=0;
            Matriz_dato_mag_extendida[2][3]=0;
            Matriz_dato_mag_extendida[3][3]=0;
        }

        //Análisis de la secuencia para contar y acumular pasos, acumular distancias y añade pasos individuales con su respectiva distancia
        double [] Matriz_analizable1 = new double [Matriz_dato_mag_extendida[0].length]; //Datos
        double [] Matriz_analizable2 = new double [Matriz_dato_mag_extendida[0].length]; //Distancias
        double [] Matriz_analizable3 = new double [Matriz_dato_mag_extendida[0].length]; //Magnitudes
        double [] Matriz_analizable4 = new double [Matriz_dato_mag_extendida[0].length]; //Tiempos
        double [] Matriz_analizable1_acortada = new double [Matriz_dato_mag_extendida[0].length];
        double [] Matriz_analizable2_acortada = new double [Matriz_dato_mag_extendida[0].length];
        double [] Matriz_analizable3_acortada = new double [Matriz_dato_mag_extendida[0].length];
        double [] Matriz_analizable4_acortada = new double [Matriz_dato_mag_extendida[0].length];
        int contador = 0;
        for(int n=0;n<Matriz_dato_mag_extendida[0].length;n++){
            if(Matriz_dato_mag_extendida[0][n]>0){ //Elimina los ceros intermedios para que sea más fácil trabajar la secuencia
                Matriz_analizable1[contador]=Matriz_dato_mag_extendida[0][n];
                Matriz_analizable2[contador]=Matriz_dato_mag_extendida[1][n];
                Matriz_analizable3[contador]=Matriz_dato_mag_extendida[2][n];
                Matriz_analizable4[contador]=Matriz_dato_mag_extendida[3][n];
                contador++;
            }
        }
        if(contador<6){ //Si hay 0,1,2,3,4 o 5 datos, acorta el vector a 5 posiciones
            Matriz_analizable1_acortada = Arrays.copyOfRange(Matriz_analizable1,0,5);
            Matriz_analizable2_acortada = Arrays.copyOfRange(Matriz_analizable2,0,5);
            Matriz_analizable3_acortada = Arrays.copyOfRange(Matriz_analizable3,0,5);
            Matriz_analizable4_acortada = Arrays.copyOfRange(Matriz_analizable4,0,5);
        }
        else if(contador>=6){ //Si hay más de 5 datos, crea el vector de la longitud contador
            Matriz_analizable1_acortada = Arrays.copyOfRange(Matriz_analizable1,0,contador);
            Matriz_analizable2_acortada = Arrays.copyOfRange(Matriz_analizable2,0,contador);
            Matriz_analizable3_acortada = Arrays.copyOfRange(Matriz_analizable3,0,contador);
            Matriz_analizable4_acortada = Arrays.copyOfRange(Matriz_analizable4,0,contador);
        } //Guarda únicamente los datos, sus distancias, sus magnitudes y tiempos

        //Genera una matriz que reúne cada dato con sus cuatro siguientes en filas
        int filasM = 0;
        if(Matriz_analizable1_acortada.length<6){ //Si hay 5 datos o menos, solo es necesaria una fila
            filasM = 1;
        }
        else if (Matriz_analizable1_acortada.length>=6){ //Si hay más de 5 datos, son necesarias (#datos - 4)
            filasM = Matriz_analizable1_acortada.length-4;
        }
        double [][] M_tripleta1 = new double [filasM][5]; //Datos
        double [][] M_tripleta2 = new double [filasM][5]; //Distancias
        double [][] M_tripleta3 = new double [filasM][5]; //Magnitudes
        double [][] M_tripleta4 = new double [filasM][5]; //Tiempos
        int aumentador = 0;
        if(filasM>1){ //Si hay más de una fila, crea los conjuntos de cinco con los datos consecutivos
            for (int q=0;q<filasM;q++){
                for (int w=0;w<5;w++){
                    aumentador++;
                    M_tripleta1[q][w]=Matriz_analizable1_acortada[aumentador-1];
                    M_tripleta2[q][w]=Matriz_analizable2_acortada[aumentador-1];
                    M_tripleta3[q][w]=Matriz_analizable3_acortada[aumentador-1];
                    M_tripleta4[q][w]=Matriz_analizable4_acortada[aumentador-1];
                }
                aumentador=aumentador-4;
            }
        }
        else if(filasM==1){ //Si hay solo una fila, crea un único conjunto de cinco con los datos consecutivos
            for (int q=0;q<5;q++){
                M_tripleta1[0][q]=Matriz_analizable1_acortada[q];
                M_tripleta2[0][q]=Matriz_analizable2_acortada[q];
                M_tripleta3[0][q]=Matriz_analizable3_acortada[q];
                M_tripleta4[0][q]=Matriz_analizable4_acortada[q];
            }
        }

        //Recorre cada fila de las matrices analizando secuencias 1-2-1-3-1 y 1-3-1-2-1,
        //mientras tiene en cuenta una distancia coherente, calculando el número acumulado de pasos, calculando y
        //acumulando la distancia actual recorrida, y agregando al vector de salida los pasos individuales con
        //sus respectivas distancias en metros.
        double [] copia_datos_matriz_extendida = new double [Matriz_dato_mag_extendida[0].length];
        for(int n=4;n<Matriz_dato_mag_extendida[0].length;n++){
            copia_datos_matriz_extendida[n]=Matriz_dato_mag_extendida[0][n];
        } //Crea una copia de respaldo para manipular en el siguiente proceso en donde posiblemente se eliminarán datos
        int conteo = 0;
        for (int n=Matriz_dato_mag_extendida[0].length-1;n>=0;n--){
            if(copia_datos_matriz_extendida[n]>0){
                conteo++;
            }
        }

        double indicador_paso = 0; //0 = nada y es necesario reconocer la racha, 1 = racha paso izquierdo, 2 = racha paso derecho
        if(Matriz_general_fx[7][2]==0){
            for (int e=0;e<filasM;e++){
                if(indicador_paso==0){
                    //SECUENCIA 1-2-1-3-1 O INICIO PASO IZQUIERDO
                    if(M_tripleta1[e][0]==1 && M_tripleta1[e][1]==2 && M_tripleta1[e][2]==1 && M_tripleta1[e][3]==3 && M_tripleta1[e][4]==1){
                        indicador_paso=1;
                    }
                    //SECUENCIA 1-3-1-2-1 O INICIO PASO DERECHO
                    if(M_tripleta1[e][0]==1 && M_tripleta1[e][1]==3 && M_tripleta1[e][2]==1 && M_tripleta1[e][3]==2 && M_tripleta1[e][4]==1){
                        indicador_paso=2;
                    }
                }
            }
            Matriz_general_fx[7][2]=indicador_paso;
        }

        int cont = 1;
        if(Matriz_general_fx[7][2]>0){
            for (int e=0;e<filasM;e++){
                //SECUENCIA 1-2-1-3-1 O INICIO PASO IZQUIERDO
                if(Matriz_general_fx[7][2]==1){
                    if(M_tripleta1[e][0]==1 && M_tripleta1[e][1]==2 && M_tripleta1[e][2]==1 && M_tripleta1[e][3]==3 && M_tripleta1[e][4]==1){
                        if(Matriz_general[6][2]!=0){
                            double dist_periodo=Math.abs(-Matriz_general[6][2]-M_tripleta2[e][3]);
                            if(dist_periodo>=34 && dist_periodo<=42){
                                Valor_K=0.3666; //Lento
                            }else if(dist_periodo>=30 && dist_periodo<=33){
                                Valor_K=0.4081; //Medio
                            }else if(dist_periodo>=23 && dist_periodo<=29){
                                Valor_K=0.4420; //Rápido
                            }
                        }
                        double distancia_paso = Valor_K*Math.sqrt(Math.sqrt(Math.abs(M_tripleta3[e][1]-M_tripleta3[e][3])));
                        Matriz_general_fx[0][2]=Matriz_general_fx[0][2]+1;
                        Matriz_general_fx[1][2]=Matriz_general_fx[1][2]+distancia_paso;
                        Matriz_general_fx[0][cont+2]=cont;
                        Matriz_general_fx[1][cont+2]=distancia_paso;
                        Matriz_general_fx[3][cont+2]=M_tripleta4[e][0]; //Tiempo inicio paso
                        Matriz_general_fx[4][cont+2]=M_tripleta4[e][4]; //Tiempo final paso
                        cont++;
                        if(M_tripleta2[e][3]>=0){
                            for(int r=Math.abs((int) M_tripleta2[e][3]);r>=0;r--){
                                copia_datos_matriz_extendida[r+4]=0;
                            }
                        }
                    }
                }
                //SECUENCIA 1-3-1-2-1 O INICIO PASO DERECHO
                if(Matriz_general_fx[7][2]==2){
                    if(M_tripleta1[e][0]==1 && M_tripleta1[e][1]==3 && M_tripleta1[e][2]==1 && M_tripleta1[e][3]==2 && M_tripleta1[e][4]==1){
                        if(Matriz_general[6][2]!=0){
                            double dist_periodo=Math.abs(-Matriz_general[6][2]-M_tripleta2[e][1]);
                            if(dist_periodo>=34 && dist_periodo<=42){
                                Valor_K=0.3666; //Lento
                            }else if(dist_periodo>=30 && dist_periodo<=33){
                                Valor_K=0.4081; //Medio
                            }else if(dist_periodo>=23 && dist_periodo<=29){
                                Valor_K=0.4420; //Rápido
                            }
                        }
                        double distancia_paso = Valor_K*Math.sqrt(Math.sqrt(Math.abs(M_tripleta3[e][1]-M_tripleta3[e][3])));
                        Matriz_general_fx[0][2]=Matriz_general_fx[0][2]+1;
                        Matriz_general_fx[1][2]=Matriz_general_fx[1][2]+distancia_paso;
                        Matriz_general_fx[0][cont+2]=cont;
                        Matriz_general_fx[1][cont+2]=distancia_paso;
                        Matriz_general_fx[3][cont+2]=M_tripleta4[e][0]; //Tiempo inicio paso
                        Matriz_general_fx[4][cont+2]=M_tripleta4[e][4]; //Tiempo final paso
                        cont++;
                        if(M_tripleta2[e][3]>=0){
                            for(int r=Math.abs((int) M_tripleta2[e][3]);r>=0;r--){
                                copia_datos_matriz_extendida[r+4]=0;
                            }
                        }
                    }
                }
            }
        }

        //Guarda los dos últimos datos encontrados en la ventana actual para pasarlos a la siguiente
        //solamente pasa los datos no analizados
        int disminuidor = 1;
        int disminu = 1;
        boolean ultimo_valle = false;
        for (int n=Matriz_dato_mag_extendida[0].length-1;n>=0;n--){ //Encuentra la distancia del último valle
            if(Matriz_dato_mag_extendida[0][n]==3 && ultimo_valle==false){
                Matriz_general_fx[6][2]=N-Matriz_dato_mag_extendida[1][n];
                ultimo_valle = true;
            }
        }
        for (int n=Matriz_dato_mag_extendida[0].length-1;n>=0;n--){
            if(copia_datos_matriz_extendida[n]>0 && disminuidor<0 && disminu>-1){
                Matriz_general_fx[4][disminu]=Matriz_dato_mag_extendida[0][n];
                Matriz_general_fx[5][disminu]=N-Matriz_dato_mag_extendida[1][n];
                Matriz_general_fx[6][disminu]=Matriz_dato_mag_extendida[2][n];
                Matriz_general_fx[7][disminu]=Matriz_dato_mag_extendida[3][n];
                disminu--;
            }
            if(copia_datos_matriz_extendida[n]>0 && disminuidor>-1){
                Matriz_general_fx[0][disminuidor]=Matriz_dato_mag_extendida[0][n];
                Matriz_general_fx[1][disminuidor]=N-Matriz_dato_mag_extendida[1][n];
                Matriz_general_fx[2][disminuidor]=Matriz_dato_mag_extendida[2][n];
                Matriz_general_fx[3][disminuidor]=Matriz_dato_mag_extendida[3][n];
                disminuidor--;
            }
        }

        //Finalmente, se revisa si en esta ventana se reconocieron pasos, si es así, conserva la racha de paso,
        //de lo contrario, la reinicia y la establece en cero
        if(Matriz_general_fx[0][3]==0){
            Matriz_general_fx[7][2]=0;
        }

        return Matriz_general_fx;
    }

    public static double [][] matrizDistanciaTiempos (double [][] Matriz_general){
        //Función para extraer de la matriz general una porción que contiene información de los pasos y sus tiempos
        double [][] distancia_tiempos = new double [3][8];
        int conteo = 0;
        for(int n=3;n<=7;n++){
            if(Matriz_general[0][n]>0){
                conteo++;
            }
        }
        if(conteo==0){
            return distancia_tiempos;
        }
        for(int n=3;n<=7;n++){
            distancia_tiempos[0][n-3]=Matriz_general[1][n];
            distancia_tiempos[1][n-3]=Matriz_general[3][n];
            distancia_tiempos[2][n-3]=Matriz_general[4][n];
        }
        return distancia_tiempos;
    }

    public static double promedioAzimuth (double t_inicio, double t_final, double [] t_110, double [] Azi){
        //Función para calcular el promedio del azimuth dentro del intervalo de tiempo en donde se detecta un paso
        int L = t_110.length;
        int indice_inicio = 0;
        int indice_final = L;
        double promedio_azimuth = 0;
        double sumas_azimuth = 0;
        double [] copia_parcial = new double [L];
        for(int n=0;n<=L-1;n++){
            if(t_110[n]==t_inicio){
                indice_inicio = n; //Halla el índice inicial basándose en el tiempo inicial
            }
        }
        for(int n=0;n<=L-1;n++){
            if(t_110[n]==t_final){
                indice_final = n; //Halla el índice final basándose en el tiempo final
            }
        }
        copia_parcial = Arrays.copyOfRange(Azi,indice_inicio,indice_final+1); //Crea una copia del intervalo a promediar

        //Excepción para controlar giros que van desde 359 a 0 grados
        int contador270 = 0;
        int contador90 = 0;
        int [] V_indices90 = new int [copia_parcial.length];
        for(int n=0;n<=copia_parcial.length-1;n++){
            if(copia_parcial[n]>=270){
                contador270++;
            }
            if(copia_parcial[n]<=90){
                V_indices90[contador90]=n+1;
                contador90++;
            }
        }
        if(contador270>0 && contador90>0){
            for(int n=0;n<=copia_parcial.length-1;n++){
                if(V_indices90[n]>0){
                    copia_parcial[V_indices90[n]-1]=copia_parcial[V_indices90[n]-1]+360;
                }
            }
        }
        //Fin del control de la excepción de giros

        //Promedio del azimuth con mayor proporción a los últimos valores
        double [] peso_porcentaje = new double [copia_parcial.length];
        for(int n=0;n<=copia_parcial.length-1;n++){
            peso_porcentaje[n]=n+1; //Se crea un vector que vaya desde 1 hasta la longitud del arreglo copiado
        }
        double sumatoria_pesos = 0;
        for(int n=0;n<=copia_parcial.length-1;n++){
            sumatoria_pesos = sumatoria_pesos + peso_porcentaje[n]; //Sumatoria de todas las cantidades
        }
        for(int n=0;n<=copia_parcial.length-1;n++){
            peso_porcentaje[n]=peso_porcentaje[n]/sumatoria_pesos; //Se divide por la el total (sumatoria) para hallar el porcentaje en proporción
        }
        for(int n=0;n<=copia_parcial.length-1;n++){
            copia_parcial[n]=copia_parcial[n]*peso_porcentaje[n]; //Se multiplica el azimuth por el porcentaje
        }
        for(int n=0;n<=copia_parcial.length-1;n++){
            promedio_azimuth = promedio_azimuth + copia_parcial[n]; //Se suman todos los aportes de cada azimuth para determinar el promedio
        }
        //Fin del promedio según un orden ascendente

        return promedio_azimuth;
    }

    public static double [][] distanciaYdireccion (double [][] MG_especifica, double [] t_110, double [] Azi){
        //Función para hallar la dirección de cada paso y juntarla en una matriz con su respectiva distancia
        double [][] fasorDD = new double [2][8];
        int desplazador = 0;
        for(int n=0;n<=7;n++){
            if(MG_especifica[0][n]>0){
                double azimuth_paso = promedioAzimuth(MG_especifica[1][n],MG_especifica[2][n],t_110, Azi);
                fasorDD[0][desplazador]=MG_especifica[0][n];
                fasorDD[1][desplazador]=azimuth_paso;
                desplazador++;
            }
        }
        return fasorDD;
    }

    public static double [][] calcularRecorrido (double [][] DyD_unidas){
        //Función para calcular el recorridos de las distancias y los ángulos
        double [][] x_y = new double [2][DyD_unidas[0].length];
        double [] theta = new  double [DyD_unidas[0].length];
        x_y[0][0]=DyD_unidas[0][0]; //Paso directamente la primera distancia
        x_y[1][0]=DyD_unidas[1][0]; //Paso directamente el primer azimuth
        int contCiclos = 1;
        for(int n=1; n<DyD_unidas[0].length; n++){
            if(DyD_unidas[0][n]!=0){
                x_y[0][contCiclos]=DyD_unidas[0][n];
                x_y[1][contCiclos]=DyD_unidas[1][n];//-DyD_unidas[1][0];
                //x_y[1][contCiclos]=x_y[1][contCiclos]*(-1);
                contCiclos++;
            }
        }
        for(int n=0; n<DyD_unidas[0].length; n++){
            theta [n] = x_y[1][n]*Math.PI/180;
            double R_aux = x_y[0][n];
            x_y[0][n] = (-1)*R_aux*Math.cos(theta[n]); //Valores de X **********
            x_y[1][n] = R_aux*Math.sin(theta[n]); //Valores de Y
        }

        for(int n=1; n<DyD_unidas[0].length; n++){
            if(x_y[0][n]!=0){
                x_y[0][n] = x_y[0][n] + x_y[0][n-1];
                x_y[1][n] = x_y[1][n] + x_y[1][n-1];
            }
        }

        return x_y;
    }

    public static double [][] rotarGrafica (double [][] MatXY_final, double angulo){
        double [][] x_y_rotado = new double[2][MatXY_final[0].length];
        double theta_rotacion = angulo*Math.PI/180;
        for(int i=0; i<MatXY_final[0].length; i++){
            if(MatXY_final[0][i]!=0){
                x_y_rotado[0][i]=(MatXY_final[0][i]*Math.cos(theta_rotacion))-(MatXY_final[1][i]*Math.sin(theta_rotacion));
                x_y_rotado[1][i]=(MatXY_final[0][i]*Math.sin(theta_rotacion))+(MatXY_final[1][i]*Math.cos(theta_rotacion));
            }
        }

        return x_y_rotado;
    }

    public void graficar (int [] xData, int [] yData){
        List<PointValue> values = new ArrayList<PointValue>();
        values.add(new PointValue(0, 0));
        for(int i=0;i<xData.length;i++){
            if(xData[i]!=0){
                values.add(new PointValue(xData[i], yData[i]));
            }
        }

        int mayorX = 0;
        int menorX = 0;
        int mayorY = 0;
        int menorY = 0;
        for(int i=0;i<xData.length;i++){
            if(xData[i]!=0){
                mayorX=Math.max(mayorX,xData[i]);
                menorX=Math.min(menorX,xData[i]);
                mayorY=Math.max(mayorY,yData[i]);
                menorY=Math.min(menorY,yData[i]);
            }
        }
        mayorX = mayorX+100;
        menorX = menorX+100;
        mayorY = mayorY+100;
        menorY = menorY+100;
        int distanciaX = mayorX-menorX;
        int distanciaY = mayorY-menorY;
        int diffXY = Math.abs(distanciaX)-Math.abs(distanciaY);

        List<PointValue> valuesMargen = new ArrayList<PointValue>();
        /*
        valuesMargen.add(new PointValue(menorX, menorY));
        valuesMargen.add(new PointValue(mayorX, menorY));
        valuesMargen.add(new PointValue(mayorX, mayorY));
        valuesMargen.add(new PointValue(menorX, mayorY));
        valuesMargen.add(new PointValue(menorX, menorY));
        */

        if(distanciaX>distanciaY){
            valuesMargen.add(new PointValue(menorX, menorY-Math.round(diffXY/2)));
            valuesMargen.add(new PointValue(mayorX, menorY-Math.round(diffXY/2)));
            valuesMargen.add(new PointValue(mayorX, mayorY+Math.round(diffXY/2)));
            valuesMargen.add(new PointValue(menorX, mayorY+Math.round(diffXY/2)));
            valuesMargen.add(new PointValue(menorX, menorY-Math.round(diffXY/2)));
        }
        else{
            valuesMargen.add(new PointValue(menorX-Math.round(diffXY/2), menorY));
            valuesMargen.add(new PointValue(mayorX+Math.round(diffXY/2), menorY));
            valuesMargen.add(new PointValue(mayorX+Math.round(diffXY/2), mayorY));
            valuesMargen.add(new PointValue(menorX-Math.round(diffXY/2), mayorY));
            valuesMargen.add(new PointValue(menorX-Math.round(diffXY/2), menorY));
        }

        Line line = new Line(values).setColor(Color.BLUE).setCubic(true);
        Line lineMargen = new Line(valuesMargen).setColor(Color.WHITE).setCubic(false).setHasPoints(false);
        List<Line> lines = new ArrayList<Line>();
        lines.add(lineMargen);
        lines.add(line);

        LineChartData data = new LineChartData();
        data.setLines(lines);

        Axis axis = new Axis();
        axis.setName("Centímetros");
        axis.setTextSize(16);
        axis.setTextColor(Color.parseColor("#03A9F4"));
        data.setAxisXBottom(axis);

        Axis yAxis = new Axis();
        yAxis.setName("Centímetros");
        yAxis.setTextColor(Color.parseColor("#03A9F4"));
        yAxis.setTextSize(16);
        data.setAxisYLeft(yAxis);

        lineChartView.setLineChartData(data);
        Viewport viewport = new Viewport(lineChartView.getMaximumViewport());
        lineChartView.setMaximumViewport(viewport);
        lineChartView.setCurrentViewport(viewport);
    }

    public static int actividadActual (double [] GyrX, double [] AccY){
        int id_act = 0;
        double sumaGyr = 0;
        double promedioGyr = 0;
        double sumaY = 0;
        double promedioY = 0;
        for(int e=0; e<GyrX.length; e++){
            sumaGyr = sumaGyr + Math.abs(GyrX[e]);
        }
        promedioGyr = sumaGyr/GyrX.length;

        for(int e=0; e<AccY.length; e++){
            sumaY = sumaY + AccY[e];
        }
        promedioY = sumaY/AccY.length;

        if(promedioGyr<0.6 && promedioY>0){
            id_act = 2; //Texteo
        }else{
            id_act = 1; //Balanceo
        }

        return id_act;
    }

}